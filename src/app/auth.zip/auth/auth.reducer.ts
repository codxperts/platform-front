import { Action } from '@ngrx/store';
import { AuthActionTypes } from './auth.actions';


export interface AuthState {

}

export const initialState: AuthState = {
  isAuthenticated: false,
  user: undefined,
  errorMessage: undefined,
  pending: undefined
};

export function authReducer(state = initialState, action: Action): AuthState {
  switch (action.type) {
    case AuthActionTypes.LOGIN: {
      return {
        ...state,
        pending: true,
        errorMessage: null
      };
    }
    case AuthActionTypes.LOGIN_SUCCESS: {
      return state;
      return {
        ...state,
        isAuthenticated: true,
        errorMessage: null,
        pending: false
      };
    }
    default:
      return state;
  }
}
