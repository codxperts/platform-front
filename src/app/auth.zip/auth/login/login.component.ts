import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { User } from '../../entities/user';
import { Store } from '@ngrx/store';
import { AppState } from '../../reducers';
import { Login, LoginSuccess } from '../auth.actions';
import { AuthService } from '../auth.service';
import { tap } from 'rxjs/operators';
import { noop } from 'rxjs';

@Component({
  selector: 'login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {

  loginForm: FormGroup;
  //user: User = new User();

  constructor(
    private formBuilder: FormBuilder,
    private store: Store<AppState>,
    private auth: AuthService
    ) { }

  ngOnInit() {
    this.loginForm = this.formBuilder.group({
      'email': ['', [Validators.required, Validators.email]],
      'password': ['', Validators.required]
    });
  }

  onSubmit(): void {
    const val = this.loginForm.value;
    this.auth.login(val.email, val.password)
    .pipe(
      tap(user => {
        console.log(user);
        this.store.dispatch(new LoginSuccess({user}));
      })
    ).subscribe(
      noop,
      () => alert('Login failed')
    );
    // const payload = this.loginForm.value;
    // this.store.dispatch(new Login(payload));
  }

}
