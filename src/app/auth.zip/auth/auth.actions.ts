import { Action } from '@ngrx/store';
import { User } from '../entities/user';

export enum AuthActionTypes {
  LOGIN = '[Login] Action',
  LOGIN_SUCCESS = '[Login Success] Action',
  LOGOUT = '[Logout] Action'
}


export class Login implements Action {

  readonly type = AuthActionTypes.LOGIN;

  constructor(public payload: any) {

  }
}

export class LoginSuccess implements Action {

  readonly type = AuthActionTypes.LOGIN_SUCCESS;

  constructor(public payload: any) {

  }
}

export class Logout implements Action {

  readonly type = AuthActionTypes.LOGOUT;

}

export type AuthActions = Login 
| LoginSuccess 
| Logout;