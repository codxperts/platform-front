import { Injectable } from '@angular/core';
import { Actions, Effect, ofType } from '@ngrx/effects';
import { Login, AuthActionTypes, Logout, LoginSuccess } from './auth.actions';
import { tap } from 'rxjs/operators';
import { Router } from '@angular/router';
import { defer, of,  } from 'rxjs';
import { AuthService } from './auth.service';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/switchMap';
import 'rxjs/add/operator/catch';
import { Observable } from 'rxjs/Observable';


@Injectable()
export class AuthEffects {

  @Effect()
  // login$ = this.actions$.pipe(
  //   ofType<Login>(AuthActionTypes.LOGIN),
  //   tap(action => {
  //     //console.log(action);
  //     const params = action.payload;
      
  //     return this.authService
  //       .login(params.email, params.password)
  //       .map(data => {
  //         return new LoginSuccess({ token: data.token, email: params.email });
  //       })
  //       .catch(error => {
  //         return error;
  //       });
  //   })
  // );

  // @Effect({dispatch: false})
  // loginSuccess$ = this.actions$.pipe(
  //   ofType<LoginSuccess>(AuthActionTypes.LOGIN_SUCCESS),
  //   tap(action => localStorage.setItem('user', JSON.stringify(action.payload.user)))
  // );

  @Effect({dispatch: false})
  logout$ = this.actions$.pipe(
    ofType<Logout>(AuthActionTypes.LOGOUT),
    tap(() => {
      localStorage.removeItem('user');
      this.router.navigateByUrl('/login');
    })
  );

  // @Effect()
  // init$ = defer(() => {
  //   const userData = localStorage.getItem('user');
  //   if(userData && userData !== 'undefined'){
  //     console.log(userData);
  //     // return of(new Login(JSON.parse(userData)))
  //   }
  //   return of(new Logout());
  // });

  constructor(
    private actions$: Actions,
    private router: Router,
    private authService: AuthService
    ) {

  }
}
